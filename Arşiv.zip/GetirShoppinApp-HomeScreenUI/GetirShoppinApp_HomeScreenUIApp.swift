//
//  GetirShoppinApp_HomeScreenUIApp.swift
//  GetirShoppinApp-HomeScreenUI
//
//  Created by Ayşe Nur Kendirci on 14.09.2025.
//

import SwiftUI

@main
struct GetirShoppinApp_HomeScreenUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
